<?php
// Database connection
$pdo = new PDO("mysql:host=localhost;dbname=4ps_system", "root", "");

// Check if a member ID is passed
if (isset($_GET['id'])) {
    $memberId = $_GET['id'];

    // Fetch member data
    $stmt = $pdo->prepare("SELECT * FROM user WHERE id = :id");
    $stmt->execute(['id' => $memberId]);
    $member = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$member) {
        die("Member not found.");
    }
}

// Handle form submission to update attendance and status
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $memberId = $_POST['member_id'];
    $attendance = isset($_POST['attendance']) ? count($_POST['attendance']) : 0;

    // Determine the status based on attendance
    $newStatus = $attendance >= 3 ? 'Inactive' : 'Active';

    // Update the status in the database
    $stmt = $pdo->prepare("UPDATE user SET status = :status WHERE id = :id");
    $stmt->execute(['status' => $newStatus, 'id' => $memberId]);

    header("Location: sup-attendance.php?id=" . $memberId);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Management</title>
    <style>
        /* Reset default styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f6f9;
            color: #333;
        }

        h1, h2, h3 {
            color: #2c3e50;
            margin-bottom: 15px;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 250px;
            height: 100vh;
            background-color: #34495e;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
        }

        .sidebar h2.am-mmdash {
            color: #ecf0f1;
            font-size: 24px;
            text-align: center;
            margin-bottom: 30px;
        }

        .sidebar nav ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar nav ul li {
            margin: 10px 0;
        }

        .sidebar nav ul li a {
            color: #ecf0f1;
            text-decoration: none;
            font-size: 18px;
            display: block;
            padding: 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }

        .sidebar nav ul li a:hover, .sidebar nav ul li a.active {
            background-color: #1abc9c;
        }

        /* Main content area */
        .container {
            margin-left: 270px;
            padding: 40px;
            max-width: 100%;
        }

        .container h1 {
            font-size: 36px;
            margin-bottom: 20px;
        }

        /* Success and error messages */
        p {
            font-size: 14px;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        p.success {
            color: green;
            background-color: #dff0d8;
        }

        p.error {
            color: red;
            background-color: #f2dede;
        }

        /* Attendance Table */
        .attendance-table-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .attendance-table-container h3 {
            font-size: 24px;
            margin-bottom: 15px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        table th {
            background-color: #34495e;
            color: #fff;
            font-size: 16px;
        }

        table td {
            font-size: 14px;
        }

        table tr:hover {
            background-color: #ecf0f1;
        }

        button {
            background-color: #1abc9c;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #16a085;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <h2 class="am-mmdash">4Ps Super Admin</h2>
        <nav>
            <ul>
                <li><a href="superadmin.php">Dashboard</a></li>
                <li><a href="adminsidemm.php">Manage Members</a></li>
                <li><a href="adminsidemeeting.php">Meeting</a></li>
                <li><a href="adminsideupdates.php">FDS Updates</a></li>
                <li><a href="admin regform.php">Register New Admin</a></li>
                <li><a href="sup-attendance.php" class="active">Attendance Management</a></li>
                <li><a href="index.php">Logout</a></li>
            </ul>
        </nav>
    </aside>


    <!-- Main Content -->
    <div class="container">

      <!-- Search Bar -->
      <div class="search-container">
            <label for="searchMember" >Search Member:</label>
            <input style="
    align-items: center;
    gap: 10px;
    margin: 20px 0; width: 600px; height: 30px;" type="text" id="searchMember" placeholder="Enter member name or ID" oninput="searchMember()">
        </div>

        <h1>Attendance Management</h1>

        <!-- Attendance Table -->
        <div class="attendance-table-container">
            <h3>Registered Members Attendance</h3>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Mobile</th>
                        <th>Address</th>
                        <th>Status</th>
                        <th>ID Number</th>
                        <th>Mark Attendance</th>
                    </tr>
                </thead>
                <tbody id="membersList">
                    <?php
                    // Connect to the database
                    try {
                        $pdo = new PDO("mysql:host=localhost;dbname=4ps_system", "root", "");

                        // Query to fetch all registered members, excluding admins and archived accounts
                        $stmt = $pdo->query("SELECT * 
                                              FROM user 
                                              WHERE archive = 0 
                                                AND role NOT IN ('admin', 'super admin')");
                        
                        // Display each registered member in a table row
                        foreach ($stmt as $row) {
                            echo "<tr>
                                    <td>" . htmlspecialchars($row['name']) . "</td>
                                    <td>" . htmlspecialchars($row['email']) . "</td>
                                    <td>" . htmlspecialchars($row['mobile']) . "</td>
                                    <td>" . htmlspecialchars($row['address']) . "</td>
                                    <td id='status_" . htmlspecialchars($row['id']) . "'>" . htmlspecialchars($row['status']) . "</td>
                                    <td>" . htmlspecialchars($row['id_number']) . "</td>
                                    <td>
                                        <form action='mark_attendance.php' method='POST' onsubmit='return handleAttendance(" . htmlspecialchars($row['id']) . ")'>
                                            <input type='hidden' name='member_id' value='" . htmlspecialchars($row['id']) . "'>
                                            <input type='hidden' name='inactive' id='inactive_" . htmlspecialchars($row['id']) . "' value='0'>
                                            <input type='checkbox' name='attendance_" . htmlspecialchars($row['id']) . "' onclick='handleAttendance(" . htmlspecialchars($row['id']) . ")'> Attendance 1
                                            <input type='checkbox' name='attendance_" . htmlspecialchars($row['id']) . "' onclick='handleAttendance(" . htmlspecialchars($row['id']) . ")'> Attendance 2
                                            <input type='checkbox' name='attendance_" . htmlspecialchars($row['id']) . "' onclick='handleAttendance(" . htmlspecialchars($row['id']) . ")'> Attendance 3
                                        </form>
                                    </td>
                                  </tr>";
                        }
                    } catch (PDOException $e) {
                        echo "<p>Error fetching data: " . $e->getMessage() . "</p>";
                    }




                    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                        try {
                            // Connect to the database
                            $pdo = new PDO("mysql:host=localhost;dbname=4ps_system", "root", "");
                            
                            // Get the member ID and inactive value from the form
                            $memberId = $_POST['member_id'];
                            $inactive = $_POST['inactive'];
                            
                            // Update the status based on attendance
                            $stmt = $pdo->prepare("UPDATE user SET status = :status WHERE id = :member_id");
                            $status = ($inactive == 1) ? 'Inactive' : 'Active';
                            $stmt->bindParam(':status', $status);
                            $stmt->bindParam(':member_id', $memberId);
                            
                            // Execute the update query
                            $stmt->execute();
                            
                            echo "<p class='success'>Attendance updated successfully.</p>";
                        } catch (PDOException $e) {
                            echo "<p class='error'>Error updating attendance: " . $e->getMessage() . "</p>";
                        }
                    }


                    ?>
                </tbody>
            </table>
        </div>
    </div>
    
    <script>
        // Function to handle checkbox checks and account status
        function handleAttendance(memberId) {
            var checkboxes = document.querySelectorAll('input[name="attendance_' + memberId + '"]:checked');
            
            // If 3 checkboxes are selected, update the status to inactive
            if (checkboxes.length >= 3) {
                document.getElementById('inactive_' + memberId).value = 1; // Mark account as inactive
                document.getElementById('status_' + memberId).textContent = 'Inactive'; // Update the status text
            } else {
                document.getElementById('inactive_' + memberId).value = 0; // Reset to active if less than 3 checkboxes
                document.getElementById('status_' + memberId).textContent = 'Active'; // Update the status text
            }
        }


        function searchMember() {
    const searchTerm = document.getElementById('searchMember').value.toLowerCase();
    const rows = document.querySelectorAll('#membersList tr');

    rows.forEach(row => {
        const name = row.cells[0].textContent.toLowerCase();  // Name is in the first column
        const idNumber = row.cells[5].textContent.toLowerCase();  // ID Number is in the sixth column (index 5)
        
        // Check if either name or ID Number includes the search term
        if (name.includes(searchTerm) || idNumber.includes(searchTerm)) {
            row.style.display = '';  // Show row if it matches the search term
        } else {
            row.style.display = 'none';  // Hide row if it doesn't match
        }
    });
}
        
    </script>
</body>
</html>
